package com.ryuzzi.ai

import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

data class AppInfo(val label: String, val pkg: String)

class CommandExecutor(
    private val context: Context,
    private val favorites: FavoritesStore,
    private val flashlight: Flashlight
) {

    fun execute(cmd: Command): String = when (cmd) {
        Command.Back -> global(AccessibilityService.GLOBAL_ACTION_BACK, "Going back.")
        Command.Home -> global(AccessibilityService.GLOBAL_ACTION_HOME, "Going home.")
        Command.Recents -> global(AccessibilityService.GLOBAL_ACTION_RECENTS, "Opening recent apps.")
        is Command.Flashlight ->
            if (flashlight.set(cmd.on)) "Flashlight ${if (cmd.on) "on" else "off"}."
            else "I couldn't control the flashlight on this device."
        Command.Time -> "It's " + LocalTime.now().format(DateTimeFormatter.ofPattern("h:mm a")) + "."
        Command.Date -> "Today is " + LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy")) + "."
        is Command.OpenSettings -> openSettings(cmd.page)
        is Command.Search -> search(cmd.query)
        is Command.OpenFavorite -> openFavorite(cmd.index)
        is Command.OpenApp -> openApp(cmd.name)
        is Command.Unknown -> "Sorry, I didn't understand \"${cmd.text}\"."
    }

    // ---- Apps ----

    @Suppress("DEPRECATION")
    fun installedApps(): List<AppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    private fun openApp(name: String): String {
        val apps = installedApps()
        val q = name.lowercase()
        val match = apps.firstOrNull { it.label.lowercase() == q }
            ?: apps.firstOrNull { it.label.lowercase().startsWith(q) }
            ?: apps.firstOrNull { it.label.lowercase().contains(q) }
            ?: return "I couldn't find an app called \"$name\"."
        return launch(match)
    }

    private fun openFavorite(index: Int): String {
        val favs = favorites.get()
        if (favs.isEmpty()) return "You have no favorite apps yet. Tap Favorites to choose some."
        val pkg = favs.getOrNull(index) ?: return "You only have ${favs.size} favorite app(s)."
        val app = installedApps().firstOrNull { it.pkg == pkg }
            ?: return "That favorite app is no longer installed."
        return launch(app)
    }

    private fun launch(app: AppInfo): String {
        val intent = context.packageManager.getLaunchIntentForPackage(app.pkg)
            ?: return "I can't launch ${app.label}."
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            begin(intent)
            "Opening ${app.label}."
        } catch (e: Exception) {
            "Couldn't open ${app.label}."
        }
    }

    // ---- Settings / search ----

    private fun openSettings(page: String?): String {
        val action = when (page) {
            "wifi", "wi fi", "internet" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "display", "screen", "brightness" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound", "volume" -> Settings.ACTION_SOUND_SETTINGS
            "apps", "app" -> Settings.ACTION_APPLICATION_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return try {
            begin(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "Opening settings."
        } catch (e: Exception) {
            "Couldn't open that settings page."
        }
    }

    private fun search(query: String): String {
        val web = Intent(Intent.ACTION_WEB_SEARCH)
            .putExtra(SearchManager.QUERY, query)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            begin(web)
            "Searching for $query."
        } catch (e: ActivityNotFoundException) {
            try {
                val url = "https://www.google.com/search?q=" + Uri.encode(query)
                begin(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "Searching for $query."
            } catch (e2: Exception) {
                "I couldn't open a browser to search."
            }
        }
    }

    /** Launch via the accessibility service's context when enabled (allowed from background), else normal context. */
    private fun begin(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val ctx: Context = RyuzziAccessibilityService.instance ?: context
        ctx.startActivity(intent)
    }

    // ---- Accessibility ----

    private fun global(action: Int, ok: String): String {
        val service = RyuzziAccessibilityService.instance
            ?: return "I need the Accessibility Service for that. Tap Accessibility and enable RYUZZI AI."
        return if (service.performGlobalAction(action)) ok else "Android refused that action."
    }
}
