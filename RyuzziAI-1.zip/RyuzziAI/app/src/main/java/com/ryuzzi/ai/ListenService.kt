package com.ryuzzi.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Foreground service (type: microphone) that keeps listening for "RYUZZI <command>".
 * Uses Android's SpeechRecognizer in a loop (not a low-power wake-word engine).
 */
class ListenService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var awaitingCommand = false
    private lateinit var executor: CommandExecutor

    private val restart = Runnable { listen() }

    private val wake = Regex("\\b(ryuzzi|ryuzi|riuzi|riuzzi|rizzi|ruzzi|ruzi|rusi|ryusi|ryuji|ryuzzy|ryuzy)\\b")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "RYUZZI listening", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 2, Intent(this, ListenService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val notif = Notification.Builder(this, CHANNEL)
            .setContentTitle("RYUZZI AI is listening")
            .setContentText("Say \"RYUZZI\" and then your command")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stop
                ).build()
            )
            .build()

        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIF_ID, notif)
            }
        } catch (e: Exception) {
            stopSelf()
            return
        }

        running = true
        executor = CommandExecutor(this, FavoritesStore(this), Flashlight(this))
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                ttsReady = true
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { schedule(300) }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { schedule(300) }
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) schedule(500)
        return START_NOT_STICKY
    }

    private fun schedule(delayMs: Long) {
        if (!running) return
        handler.removeCallbacks(restart)
        handler.postDelayed(restart, delayMs)
    }

    private fun listen() {
        if (!running) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            stopSelf()
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onError(error: Int) {
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    stopSelf()
                    return
                }
                if (error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT || error == SpeechRecognizer.ERROR_NO_MATCH) {
                    awaitingCommand = false
                }
                val busy = error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_CLIENT
                schedule(if (busy) 1500 else 400)
            }

            override fun onResults(results: Bundle?) {
                val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()?.lowercase()
                if (heard.isNullOrBlank()) schedule(300) else process(heard)
            }
        })
        recognizer = r
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        )
    }

    private fun process(text: String) {
        val m = wake.find(text)
        if (awaitingCommand) {
            awaitingCommand = false
            val cmd = if (m != null) text.substring(m.range.last + 1) else text
            if (cmd.isBlank()) schedule(200) else run(cmd)
        } else if (m != null) {
            val after = text.substring(m.range.last + 1).trim()
            if (after.isEmpty()) {
                awaitingCommand = true
                say("Yes?")
            } else run(after)
        } else {
            schedule(200)
        }
    }

    private fun run(commandText: String) {
        val cmd = CommandParser.parse(commandText)
        val result = executor.execute(cmd)
        say(if (cmd is Command.Unknown) "Sorry, I didn't understand." else result)
    }

    private fun say(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "r${System.nanoTime()}")
        else schedule(500)
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.ryuzzi.ai.STOP"
        private const val CHANNEL = "listen"
        private const val NOTIF_ID = 1
        @Volatile var running = false
    }
}
