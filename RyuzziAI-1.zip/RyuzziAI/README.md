# RYUZZI AI (Android, Kotlin)

## Build the APK (PC)
1. Install Android Studio (latest stable). It bundles JDK 17.
2. File > Open > select this RyuzziAI folder. Let Gradle sync (downloads Gradle 8.9 + SDK 35; accept licenses).
3. Build > Build APK(s). Output: app/build/outputs/apk/debug/app-debug.apk
4. Copy to the Infinix phone and install (allow "install unknown apps").
   Or enable USB debugging and press Run.

## First-run setup on the phone
- Voice: tap Speak and allow the microphone.
- Back/Home/Recents: tap Accessibility > RYUZZI AI > turn on.
  If it's greyed out (sideloaded APK): Settings > Apps > RYUZZI AI > ⋮ > Allow restricted settings, then retry.
- Infinix battery: Settings > Apps > RYUZZI AI > Battery > Unrestricted (only matters for later background features).

## Background listening (Phase 3)
- Tap "Background listening" in the app (allow mic + notifications). A notification appears; keep it.
- Say "RYUZZI, open youtube" (or say "RYUZZI", wait for "Yes?", then the command).
- Keep the Accessibility Service ON and also grant "Background launch permission" (display over other apps)
  so Android allows launching apps from the background.
- Infinix: Settings > Apps > RYUZZI AI > Battery > Unrestricted, and lock the app in Recents.
