package com.ryuzzi.ai

import android.content.Context

/** Stores favorite apps (package names, in order) in SharedPreferences. */
class FavoritesStore(context: Context) {
    private val prefs = context.getSharedPreferences("ryuzzi", Context.MODE_PRIVATE)

    fun get(): List<String> =
        prefs.getString("favs", "")!!.split("\n").filter { it.isNotBlank() }

    fun save(packages: List<String>) {
        prefs.edit().putString("favs", packages.joinToString("\n")).apply()
    }
}
