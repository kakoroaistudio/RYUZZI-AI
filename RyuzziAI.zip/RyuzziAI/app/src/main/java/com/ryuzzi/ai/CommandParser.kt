package com.ryuzzi.ai

/** Rule-based natural-language parser. Handles many phrasings of each command. */
object CommandParser {

    private val wake = Regex("^(?:hey |hi |ok |okay )?ryuzzi(?: ai)?[ ,]*")
    private val polite = Regex("^(?:please|kindly|can you|could you|would you|will you|i want you to|i want to|i wanna) +")

    fun parse(raw: String): Command {
        var t = raw.lowercase()
            .replace(Regex("[^a-z0-9' ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        t = t.replace(wake, "").trim()
        repeat(3) { t = t.replace(polite, "").trim() }
        t = t.removeSuffix(" please").trim()

        if (t.isEmpty()) return Command.Unknown(raw)

        // Navigation (needs Accessibility Service)
        if (t == "back" || has(t, "go back", "press back", "navigate back", "back button")) return Command.Back
        if (has(t, "go home", "home screen", "press home", "take me home")) return Command.Home
        if (has(t, "recent apps", "recents", "app switcher", "show overview")) return Command.Recents

        // Flashlight
        if (Regex("\\b(flash ?light|torch|flash)\\b").containsMatchIn(t)) {
            val off = Regex("\\b(off|disable|stop|kill|close)\\b").containsMatchIn(t)
            return Command.Flashlight(!off)
        }

        // Time / date
        if (has(t, "what time", "time is it", "current time", "the time", "tell me the time")) return Command.Time
        if (has(t, "what day", "today's date", "todays date", "the date", "current date")) return Command.Date

        // Search
        Regex("^(?:search up|search for|search|google|look up|find)(?: for)? (.+)$").find(t)?.let {
            return Command.Search(it.groupValues[1].trim())
        }

        // Bare "settings"
        if (t == "settings" || t == "setting") return Command.OpenSettings(null)

        // Open / launch
        Regex("^(?:open up|open|launch|start|run|go to|show me)(?: up)? (.+)$").find(t)?.let {
            val rest = it.groupValues[1].trim()

            if (rest.endsWith("settings") || rest.endsWith("setting")) {
                val page = rest.removeSuffix("settings").removeSuffix("setting").trim()
                    .removePrefix("my ").removePrefix("the ").trim()
                return Command.OpenSettings(page.ifEmpty { null })
            }
            if (Regex("\\b(favou?rite|fav)\\b").containsMatchIn(rest)) {
                val n = Regex("\\d+").find(rest)?.value?.toIntOrNull() ?: 1
                return Command.OpenFavorite((n - 1).coerceAtLeast(0))
            }
            val name = rest.removePrefix("the ").removePrefix("my ").removeSuffix(" app").trim()
            if (name.isNotEmpty()) return Command.OpenApp(name)
        }

        return Command.Unknown(raw)
    }

    private fun has(text: String, vararg phrases: String) = phrases.any { text.contains(it) }
}
