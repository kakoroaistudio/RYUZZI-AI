package com.ryuzzi.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var executor: CommandExecutor
    private lateinit var favorites: FavoritesStore

    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListening() else reply("Microphone permission denied. Voice input is off; text still works.")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Android 15 forces edge-to-edge: pad the root so content clears system bars/keyboard.
        val pad = (16 * resources.displayMetrics.density).toInt()
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(b.left + pad, b.top + pad, b.right + pad, b.bottom + pad)
            insets
        }

        log = findViewById(R.id.log)
        scroll = findViewById(R.id.scroll)
        input = findViewById(R.id.input)
        status = findViewById(R.id.status)

        favorites = FavoritesStore(this)
        executor = CommandExecutor(this, favorites, Flashlight(this))
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }

        findViewById<android.view.View>(R.id.btnSend).setOnClickListener { submit() }
        findViewById<android.view.View>(R.id.btnMic).setOnClickListener { onMicClicked() }
        findViewById<android.view.View>(R.id.btnFavs).setOnClickListener { showFavoritesDialog() }
        findViewById<android.view.View>(R.id.btnAccess).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { submit(); true } else false
        }

        append("RYUZZI AI ready. Try: \"open youtube\", \"turn on the flashlight\", \"what time is it\", " +
            "\"open settings\", \"search for minecraft\", \"open my favorite app\", \"go back\".")
    }

    override fun onResume() {
        super.onResume()
        val on = RyuzziAccessibilityService.instance != null
        status.text = "Accessibility service: " + if (on) "ON (Back/Home/Recents work)" else "OFF (needed for Back/Home/Recents)"
    }

    private fun submit() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        handle(text)
    }

    private fun handle(text: String) {
        append("You: $text")
        reply(executor.execute(CommandParser.parse(text)))
    }

    private fun reply(text: String) {
        append("RYUZZI: $text")
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ryuzzi")
    }

    private fun append(line: String) {
        log.append(line + "\n\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    // ---- Voice ----

    private fun onMicClicked() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            reply("Speech recognition isn't available on this phone. Install/enable the Google app.")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "Listening…" }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onError(error: Int) {
                    onResume()
                    reply("I didn't catch that. Tap Speak and try again.")
                }
                override fun onResults(results: Bundle?) {
                    onResume()
                    val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (heard.isNullOrBlank()) reply("I didn't catch that.") else handle(heard)
                }
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        recognizer?.startListening(i)
    }

    // ---- Favorites ----

    private fun showFavoritesDialog() {
        val apps = executor.installedApps()
        val current = favorites.get().toSet()
        val checked = BooleanArray(apps.size) { apps[it].pkg in current }
        AlertDialog.Builder(this)
            .setTitle("Choose favorite apps")
            .setMultiChoiceItems(apps.map { it.label }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Save") { _, _ ->
                favorites.save(apps.filterIndexed { i, _ -> checked[i] }.map { it.pkg })
                append("Favorites saved. Say \"open my favorite app\" (or \"open favorite 2\").")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
