package com.ryuzzi.ai

sealed class Command {
    data class OpenApp(val name: String) : Command()
    data class OpenFavorite(val index: Int) : Command()   // 0-based
    data class OpenSettings(val page: String?) : Command()
    data class Search(val query: String) : Command()
    data class Flashlight(val on: Boolean) : Command()
    object Back : Command()
    object Home : Command()
    object Recents : Command()
    object Time : Command()
    object Date : Command()
    data class Unknown(val text: String) : Command()
}
