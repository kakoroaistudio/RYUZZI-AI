package com.ryuzzi.ai

import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager

/** Torch control via CameraManager.setTorchMode (no CAMERA permission needed for torch only). */
class Flashlight(private val context: Context) {

    private val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    private val torchId: String? by lazy {
        if (!context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)) null
        else manager.cameraIdList.firstOrNull { id ->
            val c = manager.getCameraCharacteristics(id)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
    }

    /** Returns true on success. */
    fun set(on: Boolean): Boolean {
        val id = torchId ?: return false
        return try {
            manager.setTorchMode(id, on)
            true
        } catch (e: Exception) {
            false
        }
    }
}
