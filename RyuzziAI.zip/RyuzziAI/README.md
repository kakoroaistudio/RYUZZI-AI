# RYUZZI AI (Android, Kotlin)

## Build the APK (PC)
1. Install Android Studio (latest stable). It bundles JDK 17.
2. File > Open > select this RyuzziAI folder. Let Gradle sync (downloads Gradle 8.9 + SDK 35; accept licenses).
3. Build > Build APK(s). Output: app/build/outputs/apk/debug/app-debug.apk
4. Copy to the Infinix phone and install (allow "install unknown apps").
   Or enable USB debugging and press Run.

## First-run setup on the phone
- Voice: tap Speak and allow the microphone.
- Back/Home/Recents: tap Accessibility > RYUZZI AI > turn on.
  If it's greyed out (sideloaded APK): Settings > Apps > RYUZZI AI > ⋮ > Allow restricted settings, then retry.
- Infinix battery: Settings > Apps > RYUZZI AI > Battery > Unrestricted (only matters for later background features).
