package com.ryuzzi.ai

import android.content.Context
import android.os.Handler
import android.os.Looper

/** Routes text: phone commands run locally; everything else goes to the chat model. */
class Assistant(context: Context) {
    private val appCtx = context.applicationContext
    val prefs = Prefs(appCtx)
    private val executor = CommandExecutor(appCtx, FavoritesStore(appCtx), Flashlight(appCtx))
    private val chat = ChatClient(prefs)
    private val main = Handler(Looper.getMainLooper())

    fun installedApps() = executor.installedApps()

    /** onReply runs on the main thread. Second argument is true when the reply came from chat. */
    fun handle(text: String, onReply: (String, Boolean) -> Unit) {
        val cmd = CommandParser.parse(text)
        if (cmd !is Command.Unknown) {
            onReply(executor.execute(cmd), false)
            return
        }
        Thread {
            val r = chat.ask(text)
            main.post { onReply(r, true) }
        }.start()
    }
}
