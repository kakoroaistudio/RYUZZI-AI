package com.ryuzzi.ai

import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

data class AppInfo(val label: String, val pkg: String)

class CommandExecutor(
    private val context: Context,
    private val favorites: FavoritesStore,
    private val flashlight: Flashlight
) {
    private val prefs = Prefs(context)
    private fun t(en: String, id: String) = if (prefs.isIndonesian()) id else en

    fun execute(cmd: Command): String = when (cmd) {
        Command.Back -> global(AccessibilityService.GLOBAL_ACTION_BACK, t("Going back.", "Kembali."))
        Command.Home -> global(AccessibilityService.GLOBAL_ACTION_HOME, t("Going home.", "Ke layar utama."))
        Command.Recents -> global(AccessibilityService.GLOBAL_ACTION_RECENTS, t("Opening recent apps.", "Membuka aplikasi terakhir."))
        is Command.Flashlight ->
            if (flashlight.set(cmd.on)) {
                if (cmd.on) t("Flashlight on.", "Senter menyala.") else t("Flashlight off.", "Senter mati.")
            } else t("I couldn't control the flashlight on this device.", "Aku tidak bisa mengendalikan senter di HP ini.")
        Command.Time -> LocalTime.now().let {
            if (prefs.isIndonesian()) "Sekarang pukul " + it.format(DateTimeFormatter.ofPattern("HH:mm")) + "."
            else "It's " + it.format(DateTimeFormatter.ofPattern("h:mm a", prefs.locale())) + "."
        }
        Command.Date -> LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", prefs.locale())).let {
            t("Today is $it.", "Hari ini $it.")
        }
        is Command.OpenSettings -> openSettings(cmd.page)
        is Command.Search -> search(cmd.query)
        is Command.OpenFavorite -> openFavorite(cmd.index)
        is Command.OpenApp -> openApp(cmd.name)
        is Command.Unknown -> t("Sorry, I didn't understand.", "Maaf, aku tidak mengerti.")
    }

    // ---- Apps ----

    @Suppress("DEPRECATION")
    fun installedApps(): List<AppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    private fun openApp(name: String): String {
        val apps = installedApps()
        val q = name.lowercase()
        val match = apps.firstOrNull { it.label.lowercase() == q }
            ?: apps.firstOrNull { it.label.lowercase().startsWith(q) }
            ?: apps.firstOrNull { it.label.lowercase().contains(q) }
            ?: return t("I couldn't find an app called \"$name\".", "Aku tidak menemukan aplikasi \"$name\".")
        return launch(match)
    }

    private fun openFavorite(index: Int): String {
        val favs = favorites.get()
        if (favs.isEmpty()) return t("You have no favorite apps yet. Tap Favorites to choose some.",
            "Kamu belum punya aplikasi favorit. Tekan Favorites untuk memilih.")
        val pkg = favs.getOrNull(index) ?: return t("You only have ${favs.size} favorite app(s).",
            "Kamu hanya punya ${favs.size} aplikasi favorit.")
        val app = installedApps().firstOrNull { it.pkg == pkg }
            ?: return t("That favorite app is no longer installed.", "Aplikasi favorit itu sudah tidak terpasang.")
        return launch(app)
    }

    private fun launch(app: AppInfo): String {
        val intent = context.packageManager.getLaunchIntentForPackage(app.pkg)
            ?: return t("I can't launch ${app.label}.", "Aku tidak bisa membuka ${app.label}.")
        return try {
            begin(intent)
            t("Opening ${app.label}.", "Membuka ${app.label}.")
        } catch (e: Exception) {
            t("Couldn't open ${app.label}.", "Gagal membuka ${app.label}.")
        }
    }

    // ---- Settings / search ----

    private fun openSettings(page: String?): String {
        val action = when (page) {
            "wifi", "wi fi", "internet" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "battery", "baterai" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "display", "screen", "brightness", "layar", "kecerahan" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound", "volume", "suara" -> Settings.ACTION_SOUND_SETTINGS
            "apps", "app", "aplikasi" -> Settings.ACTION_APPLICATION_SETTINGS
            "location", "lokasi" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "accessibility", "aksesibilitas" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return try {
            begin(Intent(action))
            t("Opening settings.", "Membuka pengaturan.")
        } catch (e: Exception) {
            t("Couldn't open that settings page.", "Gagal membuka halaman pengaturan itu.")
        }
    }

    private fun search(query: String): String {
        val ok = t("Searching for $query.", "Mencari $query.")
        return try {
            begin(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, query))
            ok
        } catch (e: ActivityNotFoundException) {
            try {
                begin(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))))
                ok
            } catch (e2: Exception) {
                t("I couldn't open a browser to search.", "Aku tidak bisa membuka browser.")
            }
        }
    }

    /** Launch via the accessibility service's context when enabled (allowed from background), else normal context. */
    private fun begin(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val ctx: Context = RyuzziAccessibilityService.instance ?: context
        ctx.startActivity(intent)
    }

    // ---- Accessibility ----

    private fun global(action: Int, ok: String): String {
        val service = RyuzziAccessibilityService.instance
            ?: return t("I need the Accessibility Service for that. Tap Accessibility and enable RYUZZI AI.",
                "Aku butuh Accessibility Service untuk itu. Tekan Accessibility lalu aktifkan RYUZZI AI.")
        return if (service.performGlobalAction(action)) ok else t("Android refused that action.", "Android menolak aksi itu.")
    }
}
