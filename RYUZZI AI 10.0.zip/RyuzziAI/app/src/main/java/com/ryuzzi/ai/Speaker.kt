package com.ryuzzi.ai

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice

/**
 * Text-to-speech with a deep, calm "butler AI" style (lower pitch, slightly slower).
 * The actual voices come from the phone's installed TTS engine; use nextVoice() to pick one.
 */
class Speaker(context: Context, private val prefs: Prefs, private val onDone: () -> Unit = {}) {

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    var ready = false
        private set

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ready = true
                applyVoice()
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { main.post { onDone() } }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { main.post { onDone() } }
        })
    }

    private fun norm(lang: String) = if (lang == "in") "id" else lang

    private fun candidates(): List<Voice> {
        val lang = norm(prefs.locale().language)
        return (tts?.voices ?: emptySet())
            .filter { norm(it.locale.language) == lang && !it.features.contains("notInstalled") }
            .sortedBy { it.name }
    }

    fun applyVoice() {
        val t = tts ?: return
        val loc = prefs.locale()
        t.setLanguage(loc)
        t.setPitch(0.85f)
        t.setSpeechRate(0.95f)
        val list = candidates()
        val chosen = list.firstOrNull { it.name == prefs.voiceName }
            ?: if (norm(loc.language) == "en")
                list.firstOrNull { it.name.contains("gbd") || it.name.contains("gbb") }
                    ?: list.firstOrNull { it.locale.country == "GB" }
                    ?: list.firstOrNull()
            else list.firstOrNull { it.locale.country == loc.country } ?: list.firstOrNull()
        if (chosen != null) t.voice = chosen
    }

    fun speak(text: String): Boolean {
        if (!ready) return false
        return tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u${System.nanoTime()}") == TextToSpeech.SUCCESS
    }

    /** Switch to the next installed voice for the current language. Returns its name, or null if none. */
    fun nextVoice(): String? {
        val list = candidates()
        if (list.isEmpty()) return null
        val i = list.indexOfFirst { it.name == tts?.voice?.name }
        val v = list[(i + 1) % list.size]
        tts?.voice = v
        prefs.voiceName = v.name
        return v.name
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
