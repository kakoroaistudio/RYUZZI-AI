package com.ryuzzi.ai

/** Rule-based parser for English and Indonesian phone commands. Anything else becomes Unknown (-> chat). */
object CommandParser {

    private val wake = Regex("^(?:(?:hey|hi|ok|okay|hai|halo) )?ryuzzi(?: ai)?[ ,]*")
    private val polite = Regex("^(?:please|kindly|can you|could you|would you|will you|i want you to|i want to|i wanna|tolong|coba|bisakah|bisa|ayo|silakan|dong) +")
    private val tail = Regex(" (?:please|dong|donk|ya|deh|saja|aja)$")

    fun parse(raw: String): Command {
        var t = raw.lowercase()
            .replace(Regex("[^a-z0-9' ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        t = t.replace(wake, "").trim()
        repeat(3) { t = t.replace(polite, "").trim() }
        t = t.replace(tail, "").trim()
        if (t.isEmpty()) return Command.Unknown(raw)

        val n = t.split(" ").size

        // Navigation (needs Accessibility Service). Short phrases only, so normal chat isn't hijacked.
        if (t == "back" || t == "kembali" || t == "balik" ||
            (n <= 5 && has(t, "go back", "press back", "navigate back", "back button", "tekan kembali",
                "tombol kembali", "halaman sebelumnya", "kembali ke belakang"))) return Command.Back
        if (n <= 5 && has(t, "go home", "home screen", "press home", "take me home", "ke beranda",
                "layar utama", "layar depan", "tekan home")) return Command.Home
        if (n <= 5 && has(t, "recent apps", "recents", "app switcher", "show overview",
                "aplikasi terakhir", "aplikasi terbaru", "riwayat aplikasi")) return Command.Recents

        // Flashlight
        if (n <= 6 && Regex("\\b(flash ?light|torch|flash|senter)\\b").containsMatchIn(t)) {
            val off = Regex("\\b(off|disable|stop|kill|close|mati|matikan|padamkan|tutup)\\b").containsMatchIn(t)
            return Command.Flashlight(!off)
        }

        // Time / date
        if (n <= 7 && has(t, "what time is it", "what's the time", "what is the time", "tell me the time",
                "current time", "jam berapa", "pukul berapa", "waktu sekarang", "sekarang jam")) return Command.Time
        if (n <= 7 && has(t, "what day is it", "what's the date", "what is the date", "today's date",
                "todays date", "current date", "tanggal berapa", "hari apa", "tanggal hari ini")) return Command.Date

        // Search
        Regex("^(?:search up|search for|search|google|look up|find|carikan|cari|telusuri)(?: for| tentang)? (.+)$")
            .find(t)?.let { return Command.Search(it.groupValues[1].trim()) }

        // Bare settings
        if (t == "settings" || t == "setting" || t == "pengaturan" || t == "setelan") return Command.OpenSettings(null)

        // Open / launch
        Regex("^(?:open up|open|launch|buka|bukakan|jalankan|masuk ke)(?: up| aplikasi)? (.+)$").find(t)?.let {
            val rest = it.groupValues[1].trim()

            Regex("^(?:(.*) )?(?:settings?|pengaturan|setelan)(?: (.*))?$").find(rest)?.let { sp ->
                val page = (sp.groupValues[1] + " " + sp.groupValues[2]).trim()
                    .removePrefix("my ").removePrefix("the ").trim()
                return Command.OpenSettings(page.ifEmpty { null })
            }
            if (Regex("\\b(favou?rite|fav|favorit)\\b").containsMatchIn(rest)) {
                val num = Regex("\\d+").find(rest)?.value?.toIntOrNull() ?: 1
                return Command.OpenFavorite((num - 1).coerceAtLeast(0))
            }
            val name = rest.removePrefix("the ").removePrefix("my ").removePrefix("aplikasi ").removePrefix("app ")
                .removeSuffix(" app").removeSuffix(" aplikasi").trim()
            if (name.isNotEmpty()) return Command.OpenApp(name)
        }

        return Command.Unknown(raw)
    }

    private fun has(text: String, vararg phrases: String) = phrases.any { text.contains(it) }
}
