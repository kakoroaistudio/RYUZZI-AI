package com.ryuzzi.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Foreground service (type: microphone) that keeps listening for "RYUZZI <command>".
 * After a chat answer it keeps listening for a follow-up without needing the wake word.
 */
class ListenService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var awaitingCommand = false
    private lateinit var prefs: Prefs
    private lateinit var speaker: Speaker
    private lateinit var assistant: Assistant

    private val restart = Runnable { listen() }

    private val variants = setOf(
        "ryuzzi", "ryuzi", "riuzi", "riuzzi", "rizzi", "ruzzi", "ruzi", "rusi",
        "ryusi", "ryuji", "ryuzzy", "ryuzy", "riuzy", "riusi", "rizi"
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "RYUZZI listening", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 2, Intent(this, ListenService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val notif = Notification.Builder(this, CHANNEL)
            .setContentTitle("RYUZZI AI is listening")
            .setContentText("Say \"RYUZZI\" and then your command")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stop
                ).build()
            )
            .build()

        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIF_ID, notif)
            }
        } catch (e: Exception) {
            stopSelf()
            return
        }

        running = true
        prefs = Prefs(this)
        assistant = Assistant(this)
        speaker = Speaker(this, prefs) { schedule(300) }

        // Keeps the CPU awake while the screen is off so recognition keeps working (uses more battery).
        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ryuzzi:listen")
            .apply { acquire() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) schedule(800)
        return START_NOT_STICKY
    }

    private fun schedule(delayMs: Long) {
        if (!running) return
        handler.removeCallbacks(restart)
        handler.postDelayed(restart, delayMs)
    }

    private fun listen() {
        if (!running) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            stopSelf()
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onError(error: Int) {
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    stopSelf()
                    return
                }
                if (error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT || error == SpeechRecognizer.ERROR_NO_MATCH) {
                    awaitingCommand = false
                }
                val busy = error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_CLIENT
                schedule(if (busy) 1500 else 400)
            }

            override fun onResults(results: Bundle?) {
                val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (heard.isNullOrBlank()) schedule(300) else process(heard)
            }
        })
        recognizer = r
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, prefs.locale().toLanguageTag())
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        )
    }

    private fun process(text: String) {
        val words = text.lowercase()
            .replace(Regex("[^\\p{L}\\p{N} ]"), " ")
            .split(Regex("\\s+")).filter { it.isNotEmpty() }
        val idx = words.indexOfFirst { isWake(it) }

        if (awaitingCommand) {
            awaitingCommand = false
            val cmd = (if (idx >= 0) words.drop(idx + 1) else words).joinToString(" ")
            if (cmd.isBlank()) schedule(200) else run(cmd)
        } else if (idx >= 0) {
            val after = words.drop(idx + 1).joinToString(" ")
            if (after.isEmpty()) {
                awaitingCommand = true
                say(if (prefs.isIndonesian()) "Ya?" else "Yes?")
            } else run(after)
        } else {
            schedule(200)
        }
    }

    private fun run(commandText: String) {
        assistant.handle(commandText) { reply, chatted ->
            if (chatted) awaitingCommand = true   // allow a natural follow-up without the wake word
            say(reply)
        }
    }

    private fun say(text: String) {
        if (!running || !speaker.speak(text)) schedule(500)
    }

    private fun isWake(w: String) = w in variants || (w.length in 4..8 && lev(w, "ryuzzi") <= 2)

    private fun lev(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        if (this::speaker.isInitialized) speaker.shutdown()
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.ryuzzi.ai.STOP"
        private const val CHANNEL = "listen"
        private const val NOTIF_ID = 1
        @Volatile var running = false
    }
}
