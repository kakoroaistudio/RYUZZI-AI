package com.ryuzzi.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var btnListen: TextView
    private lateinit var prefs: Prefs
    private lateinit var assistant: Assistant
    private lateinit var favorites: FavoritesStore
    private lateinit var speaker: Speaker

    private var recognizer: SpeechRecognizer? = null

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListening() else reply("Microphone permission denied. Voice input is off; text still works.")
        }

    private val listenPermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
            if (r[Manifest.permission.RECORD_AUDIO] == true) startListenService()
            else reply("Microphone permission is required for background listening.")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Android 15 forces edge-to-edge: pad the root so content clears system bars/keyboard.
        val pad = (16 * resources.displayMetrics.density).toInt()
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(b.left + pad, b.top + pad, b.right + pad, b.bottom + pad)
            insets
        }

        log = findViewById(R.id.log)
        scroll = findViewById(R.id.scroll)
        input = findViewById(R.id.input)
        status = findViewById(R.id.status)
        btnListen = findViewById(R.id.btnListen)

        prefs = Prefs(this)
        favorites = FavoritesStore(this)
        assistant = Assistant(this)
        speaker = Speaker(this, prefs)

        findViewById<View>(R.id.btnSend).setOnClickListener { submit() }
        findViewById<View>(R.id.btnMic).setOnClickListener { onMicClicked() }
        findViewById<View>(R.id.btnFavs).setOnClickListener { showFavoritesDialog() }
        findViewById<View>(R.id.btnAccess).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btnListen.setOnClickListener { toggleListenService() }
        findViewById<View>(R.id.btnOverlay).setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        findViewById<View>(R.id.btnSettings).setOnClickListener { showSettingsDialog() }
        findViewById<View>(R.id.btnVoice).setOnClickListener { cycleVoice() }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { submit(); true } else false
        }

        append("RYUZZI AI 10.0 ready.\nCommands: \"open youtube\" / \"buka youtube\", \"flashlight on\" / \"nyalakan senter\", " +
            "\"what time is it\" / \"jam berapa\", \"go back\" / \"kembali\".\n" +
            "Anything else is a conversation (needs an API key in Settings).")
    }

    override fun onResume() {
        super.onResume()
        setListenLabel(ListenService.running)
        val on = RyuzziAccessibilityService.instance != null
        status.text = "Accessibility: " + if (on) "ON" else "OFF (needed for Back/Home/Recents)"
    }

    private fun submit() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        handle(text)
    }

    private fun handle(text: String) {
        append("You: $text")
        assistant.handle(text) { answer, _ -> reply(answer) }
    }

    private fun reply(text: String) {
        append("RYUZZI: $text")
        speaker.speak(text)
    }

    private fun append(line: String) {
        log.append(line + "\n\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    // ---- In-app voice ----

    private fun onMicClicked() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startListening() {
        if (ListenService.running) {
            reply("Background listening is on. Just say RYUZZI, or turn it off to use this button.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            reply("Speech recognition isn't available on this phone. Install/enable the Google app.")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "Listening…" }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onError(error: Int) {
                    onResume()
                    reply("I didn't catch that. Tap Speak and try again.")
                }
                override fun onResults(results: Bundle?) {
                    onResume()
                    val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (heard.isNullOrBlank()) reply("I didn't catch that.") else handle(heard)
                }
            })
        }
        recognizer?.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, prefs.locale().toLanguageTag())
        )
    }

    // ---- Background listening ----

    private fun toggleListenService() {
        if (ListenService.running) {
            stopService(Intent(this, ListenService::class.java))
            setListenLabel(false)
            append("Background listening stopped.")
        } else {
            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            listenPermissions.launch(perms.toTypedArray())
        }
    }

    private fun startListenService() {
        try {
            ContextCompat.startForegroundService(this, Intent(this, ListenService::class.java))
            setListenLabel(true)
            append("Background listening started. Say \"RYUZZI\" and then your command, even from other apps.")
        } catch (e: Exception) {
            reply("Android refused to start the listening service.")
        }
    }

    private fun setListenLabel(on: Boolean) {
        btnListen.text = "Background listening: " + if (on) "ON" else "OFF"
    }

    // ---- Voice style ----

    private fun cycleVoice() {
        val name = speaker.nextVoice()
        if (name == null) {
            append("No installed voice found for this language. Install voice data in Settings > Language > Text-to-speech.")
        } else {
            append("Voice: $name")
            speaker.speak(if (prefs.isIndonesian()) "Halo, aku Ryuzzi. Siap membantu." else "Good day. I am Ryuzzi. At your service.")
        }
    }

    // ---- Settings ----

    private fun showSettingsDialog() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, 0)
        }
        val keyIn = EditText(this).apply {
            hint = "Anthropic API key (sk-ant-...)"
            setText(prefs.apiKey)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val modelIn = EditText(this).apply {
            hint = "Model"
            setText(prefs.model)
        }
        val group = RadioGroup(this)
        listOf("auto" to "Auto (phone language)", "id" to "Bahasa Indonesia", "en" to "English (British voice)")
            .forEach { (value, label) ->
                val rb = RadioButton(this).apply {
                    id = View.generateViewId()
                    text = label
                    tag = value
                    isChecked = prefs.lang == value
                }
                group.addView(rb)
            }
        box.addView(keyIn)
        box.addView(modelIn)
        box.addView(group)

        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Save") { _, _ ->
                prefs.apiKey = keyIn.text.toString()
                prefs.model = modelIn.text.toString()
                group.findViewById<RadioButton>(group.checkedRadioButtonId)?.let { prefs.lang = it.tag as String }
                prefs.voiceName = ""
                speaker.applyVoice()
                append("Settings saved. If background listening is on, turn it off and on again to apply the language.")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---- Favorites ----

    private fun showFavoritesDialog() {
        val apps = assistant.installedApps()
        val current = favorites.get().toSet()
        val checked = BooleanArray(apps.size) { apps[it].pkg in current }
        AlertDialog.Builder(this)
            .setTitle("Choose favorite apps")
            .setMultiChoiceItems(apps.map { it.label }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Save") { _, _ ->
                favorites.save(apps.filterIndexed { i, _ -> checked[i] }.map { it.pkg })
                append("Favorites saved. Say \"open my favorite app\" (or \"open favorite 2\").")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        speaker.shutdown()
        super.onDestroy()
    }
}
