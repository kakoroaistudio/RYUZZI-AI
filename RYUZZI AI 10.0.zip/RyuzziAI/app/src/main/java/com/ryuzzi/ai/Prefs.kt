package com.ryuzzi.ai

import android.content.Context
import java.util.Locale

/** App settings (stored privately on this phone). */
class Prefs(context: Context) {
    private val p = context.applicationContext.getSharedPreferences("ryuzzi", Context.MODE_PRIVATE)

    var apiKey: String
        get() = p.getString("apiKey", "")!!
        set(v) { p.edit().putString("apiKey", v.trim()).apply() }

    var model: String
        get() = p.getString("model", DEFAULT_MODEL)!!
        set(v) { p.edit().putString("model", v.trim().ifEmpty { DEFAULT_MODEL }).apply() }

    /** "auto", "id" or "en" */
    var lang: String
        get() = p.getString("lang", "auto")!!
        set(v) { p.edit().putString("lang", v).apply() }

    var voiceName: String
        get() = p.getString("voiceName", "")!!
        set(v) { p.edit().putString("voiceName", v).apply() }

    fun isIndonesian(): Boolean =
        lang == "id" || (lang == "auto" && Locale.getDefault().language in setOf("id", "in"))

    fun locale(): Locale = when (lang) {
        "id" -> Locale("id", "ID")
        "en" -> Locale.UK
        else -> Locale.getDefault()
    }

    companion object {
        const val DEFAULT_MODEL = "claude-haiku-5-5"
    }
}
