package com.ryuzzi.ai

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Talks to the Claude API (Messages endpoint) with the user's own API key. Call off the main thread. */
class ChatClient(private val prefs: Prefs) {

    private val history = ArrayList<Pair<String, String>>() // role to text

    fun ask(userText: String): String {
        val id = prefs.isIndonesian()
        if (prefs.apiKey.isBlank()) {
            return if (id) "Aku belum mengerti. Untuk bisa ngobrol, masukkan API key di menu Settings."
            else "I didn't understand that. To chat with me, add an API key in Settings."
        }
        synchronized(history) {
            history.add("user" to userText)
            while (history.size > 12) history.removeAt(0)
            while (history.isNotEmpty() && history[0].first != "user") history.removeAt(0)

            val msgs = JSONArray()
            history.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
            val body = JSONObject()
                .put("model", prefs.model)
                .put("max_tokens", 300)
                .put("system", SYSTEM)
                .put("messages", msgs)

            try {
                val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 15000
                c.readTimeout = 30000
                c.doOutput = true
                c.setRequestProperty("content-type", "application/json")
                c.setRequestProperty("x-api-key", prefs.apiKey)
                c.setRequestProperty("anthropic-version", "2023-06-01")
                c.outputStream.use { it.write(body.toString().toByteArray()) }

                val code = c.responseCode
                val text = (if (code in 200..299) c.inputStream else c.errorStream)
                    ?.bufferedReader()?.use { it.readText() } ?: ""

                if (code !in 200..299) {
                    history.removeAt(history.size - 1)
                    return errorMessage(code, text, id)
                }
                val blocks = JSONObject(text).getJSONArray("content")
                val sb = StringBuilder()
                for (i in 0 until blocks.length()) {
                    val b = blocks.getJSONObject(i)
                    if (b.optString("type") == "text") sb.append(b.getString("text"))
                }
                val reply = sb.toString().trim().ifEmpty { if (id) "Maaf, aku tidak punya jawaban." else "Sorry, I have no answer." }
                history.add("assistant" to reply)
                return reply
            } catch (e: Exception) {
                history.removeAt(history.size - 1)
                return if (id) "Maaf, koneksi internet bermasalah." else "Sorry, I can't reach the internet."
            }
        }
    }

    private fun errorMessage(code: Int, body: String, id: Boolean): String {
        val detail = try { JSONObject(body).getJSONObject("error").getString("message") } catch (e: Exception) { "" }
        return when (code) {
            401 -> if (id) "API key tidak valid. Periksa di Settings." else "The API key is invalid. Check it in Settings."
            429 -> if (id) "Terlalu banyak permintaan. Coba lagi sebentar." else "Too many requests. Try again shortly."
            else -> (if (id) "Kesalahan API $code: " else "API error $code: ") + detail.take(150)
        }
    }

    companion object {
        private val SYSTEM = """
            You are RYUZZI, a calm, polite, quietly witty voice assistant living on the user's Android phone, in the manner of a butler-style AI.
            Your replies are spoken aloud, so answer in one to three short sentences of plain text. No markdown, no lists, no emoji.
            Always reply in the language the user speaks (usually Indonesian or English).
            Phone actions (opening apps, flashlight, settings, back, search, time) are handled by separate voice commands, not by you. If asked to do one, briefly tell the user to say it as a command, for example "RYUZZI, buka YouTube".
            If you don't know something, say so plainly.
        """.trimIndent()
    }
}
